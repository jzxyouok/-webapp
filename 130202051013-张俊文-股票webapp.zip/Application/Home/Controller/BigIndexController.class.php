<?php
/**
 * Created by PhpStorm.
 * User: 123
 * Date: 2015-10-24
 * Time: 14:09
 */

namespace Home\Controller;
use Think\Controller;


class BigIndexController extends Controller {

    public function  index()
    {
        $this->display();
    }

}