<?php
return array(
    //'配置项'=>'配置值'
    'MODULE_ALLOW_LIST'    =>    array('Home','Backstage'),
    'DEFAULT_MODULE'       =>    'Home',
);