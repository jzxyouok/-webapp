<?php
/**
 * Created by PhpStorm.
 * User: 123
 * Date: 2015-09-25
 * Time: 19:51
 */

namespace Home\Controller;


use Think\Controller;

class MyInfoController extends Controller {
    public function index()
    {
        $this->display();

    }

}