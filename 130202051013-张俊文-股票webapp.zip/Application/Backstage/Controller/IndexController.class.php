<?php
/**
 * Created by PhpStorm.
 * User: 123
 * Date: 2015-10-04
 * Time: 15:12
 */

namespace Backstage\Controller;
use Think\Controller;



class IndexController extends Controller {

    public function index()
    {

       $this->display();
    }

}