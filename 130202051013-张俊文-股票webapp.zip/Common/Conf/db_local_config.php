<?php
/**
 * Created by PhpStorm.
 * User: 123
 * Date: 2015-11-01
 * Time: 16:38
 */

return array(
    // 本机
    'DB_TYPE' => 'mysql',
    'DB_HOST' => '127.0.0.1',
    'DB_NAME' => 'money',
    'DB_USER' => 'root',
    'DB_PWD' => 'root',
    'DB_PORT' => '3306',
    'DB_PREFIX' => '',
);
